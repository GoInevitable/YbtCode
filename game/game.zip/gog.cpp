#include <iostream>
#include <cstdlib>
#include <ctime>
#include <conio.h>   // 用于Windows下的键盘输入，如果非Windows系统可能需要替换
#include <windows.h> // 用于Sleep函数和清屏，如果非Windows系统可能需要调整

using namespace std;

// 游戏常量
const int SCREEN_WIDTH = 50;
const int SCREEN_HEIGHT = 10;
const int GROUND_LEVEL = SCREEN_HEIGHT - 2;
const char DINO_CHAR = '@';
const char OBSTACLE_CHAR = '#';
const char GROUND_CHAR = '_';
const char EMPTY_CHAR = ' ';

// 恐龙状态
struct Dino {
    int x, y;          // 位置
    int velocity;      // 垂直速度
    bool isJumping;    // 是否在跳跃
};

// 障碍物状态
struct Obstacle {
    int x, y;          // 位置
    bool active;       // 是否活动
};

// 游戏状态
int score = 0;
bool gameOver = false;
Dino dino = {5, GROUND_LEVEL, 0, false}; // 恐龙初始位置
Obstacle obstacles[3]; // 最多3个障碍物
int obstacleSpeed = 2;  // 障碍物移动速度

// 初始化游戏
void initGame() {
    srand(time(0)); // 随机种子
    dino.x = 5;
    dino.y = GROUND_LEVEL;
    dino.velocity = 0;
    dino.isJumping = false;
    score = 0;
    gameOver = false;
    obstacleSpeed = 2;
    
    // 初始化障碍物
    for (int i = 0; i < 3; i++) {
        obstacles[i].active = false;
        obstacles[i].x = SCREEN_WIDTH;
        obstacles[i].y = GROUND_LEVEL;
    }
    
    // 生成第一个障碍物
    obstacles[0].active = true;
    obstacles[0].x = SCREEN_WIDTH - 10;
}

// 清屏函数（跨平台简化版，Windows用system("cls")，其他系统用system("clear")）
void clearScreen() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

// 绘制游戏界面
void draw() {
    char screen[SCREEN_HEIGHT][SCREEN_WIDTH + 1]; // +1 用于字符串终止符
    // 初始化屏幕为空格
    for (int i = 0; i < SCREEN_HEIGHT; i++) {
        for (int j = 0; j < SCREEN_WIDTH; j++) {
            screen[i][j] = EMPTY_CHAR;
        }
        screen[i][SCREEN_WIDTH] = '\0'; // 行终止符
    }
    
    // 绘制地面
    for (int j = 0; j < SCREEN_WIDTH; j++) {
        screen[GROUND_LEVEL][j] = GROUND_CHAR;
    }
    
    // 绘制恐龙
    if (dino.y >= 0 && dino.y < SCREEN_HEIGHT && dino.x >= 0 && dino.x < SCREEN_WIDTH) {
        screen[dino.y][dino.x] = DINO_CHAR;
    }
    
    // 绘制障碍物
    for (int i = 0; i < 3; i++) {
        if (obstacles[i].active) {
            if (obstacles[i].y >= 0 && obstacles[i].y < SCREEN_HEIGHT && obstacles[i].x >= 0 && obstacles[i].x < SCREEN_WIDTH) {
                screen[obstacles[i].y][obstacles[i].x] = OBSTACLE_CHAR;
            }
        }
    }
    
    // 输出屏幕
    clearScreen();
    for (int i = 0; i < SCREEN_HEIGHT; i++) {
        cout << screen[i] << endl;
    }
    
    // 显示分数和说明
    cout << "分数: " << score << endl;
    cout << "按空格键跳跃，按'q'键退出游戏" << endl;
    if (gameOver) {
        cout << "游戏结束！按'r'键重新开始" << endl;
    }
}

// 处理输入
void handleInput() {
    if (_kbhit()) { // 检查是否有键盘输入（Windows特定，非Windows系统可能需要替换）
        char key = _getch();
        if (key == ' ' && !dino.isJumping && dino.y == GROUND_LEVEL) {
            dino.velocity = -4; // 向上跳跃速度
            dino.isJumping = true;
        } else if (key == 'q') {
            gameOver = true; // 退出游戏
        } else if (key == 'r' && gameOver) {
            initGame(); // 重新开始
        }
    }
}

// 更新游戏状态
void update() {
    if (gameOver) return;
    
    // 更新恐龙位置（重力模拟）
    dino.y += dino.velocity;
    dino.velocity += 1; // 重力加速度
    
    // 限制恐龙在地面以上
    if (dino.y > GROUND_LEVEL) {
        dino.y = GROUND_LEVEL;
        dino.velocity = 0;
        dino.isJumping = false;
    }
    if (dino.y < 0) {
        dino.y = 0;
        dino.velocity = 0;
    }
    
    // 更新障碍物位置
    for (int i = 0; i < 3; i++) {
        if (obstacles[i].active) {
            obstacles[i].x -= obstacleSpeed; // 向左移动
            if (obstacles[i].x < 0) {
                obstacles[i].active = false;
                score += 10; // 每越过一个障碍物得10分
                // 随机生成新障碍物
                if (rand() % 3 == 0) { // 33%概率生成新障碍物
                    for (int j = 0; j < 3; j++) {
                        if (!obstacles[j].active) {
                            obstacles[j].active = true;
                            obstacles[j].x = SCREEN_WIDTH;
                            obstacles[j].y = GROUND_LEVEL;
                            break;
                        }
                    }
                }
            }
        }
    }
    
    // 碰撞检测
    for (int i = 0; i < 3; i++) {
        if (obstacles[i].active && dino.x == obstacles[i].x && dino.y == obstacles[i].y) {
            gameOver = true;
            break;
        }
    }
    
    // 随时间增加难度
    if (score > 50 && obstacleSpeed < 5) {
        obstacleSpeed = 3;
    } else if (score > 100) {
        obstacleSpeed = 4;
    }
}

// 主函数
int main() {
    initGame();
    while (true) {
        draw();
        handleInput();
        if (gameOver && _kbhit()) {
            char key = _getch();
            if (key == 'q') break; // 退出主循环
        }
        update();
        Sleep(100); // 控制游戏速度，100毫秒一帧
    }
    return 0;
}
